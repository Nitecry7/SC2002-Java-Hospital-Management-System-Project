public class Inventory 
{
    // not using anymore
}
