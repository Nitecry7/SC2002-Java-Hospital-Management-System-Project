public class AppointmentOutcome {
    
}
