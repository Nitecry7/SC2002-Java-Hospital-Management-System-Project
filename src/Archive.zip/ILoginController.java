public interface ILoginController{


    public User authenticate(String userID, String password) throws Exception;

}
