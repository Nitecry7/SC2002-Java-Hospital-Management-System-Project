public enum Frequency{
    PRN,
    BD,
    TDS,
    QDS,
    MANE,
    NOCTE
}