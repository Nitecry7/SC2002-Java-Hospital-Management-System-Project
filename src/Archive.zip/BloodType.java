
public enum BloodType {
    Oneg,
    Opos,
    Aneg,
    Apos,
    Bneg,
    Bpos,
    ABneg,
    ABpos,
    NOT_SET
}
