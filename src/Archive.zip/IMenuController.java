public interface IMenuController {

    public void takeInput();

}
