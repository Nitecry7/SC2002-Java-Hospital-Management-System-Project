
public interface ILoginHandler {
    public User authenticate() throws Exception;
}
